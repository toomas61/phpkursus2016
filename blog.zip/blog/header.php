<hmtl>
<head>
<title>Blog</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
</head>
<body>
<a href=insert.php>Sisestamine</a> |
<a href=show.php>Vaatamine</a> |
<a href=search.php>Otsimine</a>
</body>
</html>