<?php

@mysql_connect("localhost", "ta10_user", "KAikjotja2010") OR
die("DB server k�ttesaamatu");

@mysql_select_db("ta10") OR
die("DB k�ttesaamatu");

?>