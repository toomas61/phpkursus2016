<html>
<head>
</head>
<body>
<hr noshade size=1 />
Copyright &copy; <?php echo date("Y"); ?>
</body>
</html>