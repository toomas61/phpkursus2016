<?php

  #we use HTML entitities to hide latin text, just a little trick
  echo "<i>&#67;&#111;&#112;&#121;&#114;&#105;&#103;&#104;&#116;
  &#32;(&#99;)&#32;&#50;&#48;&#48;&#57;&#45;".date("Y")."</i>";

?>

</html>